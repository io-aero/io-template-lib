# IO-TEMPLATE-LIB - Template for Library Repositories

This repository is a sample repository for developing Python related IO-Aero libraries.

## Documentation

The complete documentation for this repository is contained in the github pages [here](https://io-aero.github.io/io-template-lib/). 
See that documentation for installation instructions
